/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>
using namespace std;
  
class Node {
public:
    int data;
    Node* next;
};
  

void printList(Node* n)
{
    while (n != NULL) {
        cout << n->data << " ";
        n = n->next;
    }
}
  

int main()
{
    Node* head = NULL;
    Node* second = NULL;
    Node* third = NULL;
  
   
    head = new Node();
    second = new Node();
    third = new Node();
  
    head->data = 1; 
    head->next = second; 
  
    second->data = 2; 
    second->next = third;
  
    third->data = 3; 
    third->next = NULL;
  
    // Function call
    printList(head);
  
    return 0;
}
  
